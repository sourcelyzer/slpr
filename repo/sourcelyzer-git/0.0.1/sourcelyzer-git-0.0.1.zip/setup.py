from setuptools import setup, find_packages

setup(
    name="Sourcelyzer GIT Plugin",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[
        'GitPython'
    ]
    author="Sourcelyzer",
    author_email="admin@sourcelyzer.org",
    description="GIT plugin for Sourcelyzer",
    license="MIT",
    url="https://github.com/sourcelzyer/sourcelzyer-git"
)
