def commit_log(project):
   pass
