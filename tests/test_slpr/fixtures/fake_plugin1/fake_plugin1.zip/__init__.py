class Plugin():
    pass
